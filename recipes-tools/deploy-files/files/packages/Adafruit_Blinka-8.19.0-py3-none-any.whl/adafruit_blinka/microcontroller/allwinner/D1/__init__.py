# SPDX-FileCopyrightText: 2022 Aleksandr Saiapin for Adafruit Industries
#
# SPDX-License-Identifier: MIT
"""Definition for the AllWinner D1 chip"""
